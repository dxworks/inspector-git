package org.gitsecond.test;

//some comment from second

public class Main {

    public static void main(String[] args) {
        System.out.println("From main");

        System.out.println("This is done from the second branch");

        System.out.println("Fuck nobody!!!!!");

        for(int i=0; i<100; i++) {
            System.out.println("Darius are Mere");
        }

    }
}
