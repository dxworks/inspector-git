package org.gitsecond.test;

public class BlaRenamed {
    @Override public String toString() {
        return super.toString();
    }
}
