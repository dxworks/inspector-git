package org.gitsecond;

public class SomeClass {

    public String someMethod() {
        System.out.println("This method is really nothing! :))");
        //icu
        System.out.println("This method is anything! :))");
        // todo: nothing

        return "Something is fishy!";
    }
}
