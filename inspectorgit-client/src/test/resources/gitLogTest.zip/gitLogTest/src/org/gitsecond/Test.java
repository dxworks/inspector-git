package org.gitsecond;

public class Test {
    //this is no more a test class

    public static void main(String[] args) {
        System.out.println("Something");
    }
}
